//var hamburger = document.querySelector(".navBurger");
//hamburger.addEventListener("click", function(){
//    document.querySelector("body").classList.toggle("active");
//})